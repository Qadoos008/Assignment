#include <iostream>
#include <queue>
#include <string>

using namespace std;

// ------------------- Patient Class -------------------
class Patient {
private:
    static int idCounter;
public:
    int id;
    string name;
    int age;
    string gender;
    string serviceType;
    bool isPregnant;

    Patient(string n, int a, string g, string s, bool preg)
        : name(n), age(a), gender(g), serviceType(s), isPregnant(preg) {
        id = ++idCounter;
    }

    bool isPriority() const {
        return age >= 60 || isPregnant;
    }
};

int Patient::idCounter = 0;

// ------------------- ClinicQueue Class -------------------
class ClinicQueue {
private:
    queue<Patient> priorityQueue;
    queue<Patient> normalQueue;

public:
    void addPatient() {
        string name, gender, serviceType;
        int age;
        bool preg;

        cin.ignore(); // Clear input buffer

        cout << "Enter patient name: ";
        getline(cin, name);

        cout << "Enter gender (Male/Female/Other): ";
        getline(cin, gender);

        cout << "Enter age: ";
        cin >> age;
        cin.ignore();

        cout << "Enter service type (e.g. General Checkup, Vaccination): ";
        getline(cin, serviceType);

        cout << "Is the patient pregnant? (1 = Yes, 0 = No): ";
        cin >> preg;

        Patient p(name, age, gender, serviceType, preg);

        if (p.isPriority())
            priorityQueue.push(p);
        else
            normalQueue.push(p);

        cout << "Patient added. Assigned ID: " << p.id << "\n";
    }

    void servePatient() {
        if (!priorityQueue.empty()) {
            Patient p = priorityQueue.front();
            priorityQueue.pop();
            cout << "Serving PRIORITY patient: " << p.name << " (ID: " << p.id << ")\n";
        } else if (!normalQueue.empty()) {
            Patient p = normalQueue.front();
            normalQueue.pop();
            cout << "Serving normal patient: " << p.name << " (ID: " << p.id << ")\n";
        } else {
            cout << "No patients in queue.\n";
        }
    }

    void showQueues() {
        queue<Patient> tempP = priorityQueue;
        queue<Patient> tempN = normalQueue;

        cout << "\n--- Priority Queue ---\n";
        while (!tempP.empty()) {
            Patient p = tempP.front();
            cout << "ID: " << p.id << " | Name: " << p.name
                 << " | Age: " << p.age << " | Gender: " << p.gender
                 << " | Pregnant: " << (p.isPregnant ? "Yes" : "No")
                 << " | Service: " << p.serviceType << "\n";
            tempP.pop();
        }

        cout << "\n--- Normal Queue ---\n";
        while (!tempN.empty()) {
            Patient p = tempN.front();
            cout << "ID: " << p.id << " | Name: " << p.name
                 << " | Age: " << p.age << " | Gender: " << p.gender
                 << " | Pregnant: " << (p.isPregnant ? "Yes" : "No")
                 << " | Service: " << p.serviceType << "\n";
            tempN.pop();
        }
    }

    void searchPatientByID(int targetID) {
        bool found = false;

        queue<Patient> tempP = priorityQueue;
        while (!tempP.empty()) {
            Patient p = tempP.front(); tempP.pop();
            if (p.id == targetID) {
                cout << "\nFound in Priority Queue:\n";
                displayPatientDetails(p);
                found = true;
                break;
            }
        }

        if (!found) {
            queue<Patient> tempN = normalQueue;
            while (!tempN.empty()) {
                Patient p = tempN.front(); tempN.pop();
                if (p.id == targetID) {
                    cout << "\nFound in Normal Queue:\n";
                    displayPatientDetails(p);
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            cout << "\nPatient ID not found.\n";
        }
    }

    void displayPatientDetails(const Patient& p) {
        cout << "ID: " << p.id << "\n";
        cout << "Name: " << p.name << "\n";
        cout << "Age: " << p.age << "\n";
        cout << "Gender: " << p.gender << "\n";
        cout << "Service Type: " << p.serviceType << "\n";
        cout << "Pregnant: " << (p.isPregnant ? "Yes" : "No") << "\n";
    }
};

// ------------------- Main Function -------------------
int main() {
    ClinicQueue clinic;
    int choice;

    do {
        cout << "\n=== Clinic Queue Menu ===\n";
        cout << "1. Add New Patient\n";
        cout << "2. Serve Next Patient\n";
        cout << "3. Display All Queues\n";
        cout << "4. Search Patient by ID\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                clinic.addPatient();
                break;
            case 2:
                clinic.servePatient();
                break;
            case 3:
                clinic.showQueues();
                break;
            case 4: {
                int id;
                cout << "Enter patient ID to search: ";
                cin >> id;
                clinic.searchPatientByID(id);
                break;
            }
            case 0:
                cout << "Exiting the system...\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 0);

    return 0;
}
